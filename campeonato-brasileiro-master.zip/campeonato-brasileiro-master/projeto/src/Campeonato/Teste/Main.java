package Projeto.Teste;

import Projeto.Conn.ConnectionFactory;
import Projeto.classes.Partidas;
import Projeto.db.Jogodb;
import Projeto.db.Requisitosdb;
import Projeto.db.timedb;

public class Main {

    public static void main(String[] args) {
        Partidas.JogarPartida();
    }
}
